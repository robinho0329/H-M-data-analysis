import pandas as pd 
import numpy as np
import time
from PIL import Image

import altair as alt
import seaborn as sns
import matplotlib.pyplot as plt 
from sklearn.preprocessing import StandardScaler

# seaborn 팔레트 설정
palette = sns.color_palette("pastel")

import warnings
# 오류 경고 무시하기
warnings.filterwarnings(action='ignore')


# pandas 라이브러리를 활용한 csv 파일 읽기 
articles = pd.read_csv("articles_hm.csv") 
customers = pd.read_csv("customer_hm.csv") 
transactions = pd.read_csv("transactions_hm.csv") 



# EDA

# 1. 분석할 데이터의 행/열 개수를 제시 
articles.info()
customers.info()
transactions.info()


# 2. 분석할 데이터의 컬럼 타입과 기술통계(min/median/mean/max, 결측치 수)를 제시하여 EDA를 수행
articles.describe() 
customers.describe()
transactions.describe()

# 3. 결측치 확인

print(articles.isnull().sum())
print(customers.isnull().sum())
print(transactions.isnull().sum())

# 전처리

# 1. Articles detail_desc  컬럼 삭제 (결측치 삭제)
# 코드
articles = articles.drop(labels='detail_desc', axis=1)

# 처리 이유 : articles 테이블에서 결측치가 발생한 컬럼이 detail_desc인데, 
# 이는 상품에 대한 정보 컬럼으로, 추후 merge시 필요없는 데이터 이기에 삭제함

# 2. Club_member_stauts 탈퇴고객 삭제 (이상치 삭제)
# 코드
customers = customers[customers['club_member_status'] != 'LEFT CLUB']

# 처리 이유 : 데이터 분석 중 탈퇴고객의 비중이 작고(약 350개 정도),
# 신규, 기존 회원들로 분석하여 인사이트 도출, 전략 수립을 해야 하기에 삭제

# 3. Fashion_news_frequency 결측치 fillna(“Unknown”) 처리
# 코드
customers["club_member_status"] = customers["club_member_status"].fillna("Unknown")

# 처리 이유 : club member status 중 결측치 발생하여, 
# 추후 데이터 분석 시 오류 발생 방지를 위하여 fillna로 결측치 치환 

# 4. articles-customers-transactions inner join 단일 데이터셋 생성 + age_group 컬럼 생성
# 코드
df_tr_cu_inner = transactions.merge(customers, on="customer_id", how="inner")
df_full = df_tr_cu_inner.merge(articles, on="article_id", how="inner")
df_full["age_group"] = (df_full["age"] // 10) * 10

# 처리 이유: 문제 정의해결 시 '거래를 한 고객들' 위주로의 데이터 분석이 이루어지기에,
# 거래가 없는 데이터들은 inner로 하여 제거

# 5. price 컬럼 이상치 확인
# transactions의 price 컬럼의 분포를 히스토그램으로 확인
# 정규분포를 따르지 않음
plt.figure(figsize=(12, 5))
plt.hist(transactions['price'], bins=70, density=True, edgecolor='black')
plt.show() 

# 로그 변환
transactions['price_log'] = np.log(transactions['price'])

# 원래 가격 컬럼과 로그 변환 가격 컬럼 비교 시각화
fig, axes = plt.subplots(1, 2, figsize=(12, 5))
axes[0].hist(transactions['price'], bins=100)
axes[0].set_title("Original (Normalized) Price")
axes[1].hist(transactions['price_log'], bins=100)
axes[1].set_title("Log-transformed Price")
plt.show()

## 이상치 판별 - transactions 의 price 이상치 판별
# 가격 이상치 판별1 - Z-Score(StandardScaler)
# 필요한 컬럼만 가져오기
df2 = transactions[['customer_id', 'price_log']].copy()

# price_log을 2D 형태로 변환하여 스케일링
df2['zscore'] = StandardScaler().fit_transform(df2[['price_log']])

# 이상치 판단
mask2 = ((df2['zscore']<-3) | (df2['zscore']>3))
strange_df2 = df2[mask2].reset_index(drop=True)

# Z-score 방식으로 구한 이상치 개수는 6614개 
cnt_zscore2 = strange_df2['zscore'].count()
print("Z-score 방식 이상치", cnt_zscore2)

## 가격 이상치 판별2 - IQR(Interquartile Range)
q3 = transactions['price_log'].quantile(0.75) 
q1 = transactions['price_log'].quantile(0.25)

iqr = q3 - q1

def is_outlier(transactions):
    score = transactions['price_log']
    if score > q3 + (1.5 * iqr) or score < q1 - (1.5 * iqr):
        return '이상치'
    else:
        return '이상치아님'

transactions['이상치여부'] = transactions.apply(is_outlier, axis = 1) 

# IQR 방식으로 구한 이상치 개수는 21878개
cnt_iqr2 = transactions[transactions['이상치여부'] == '이상치']['price'].count()
print('IQR 방식 이상치', cnt_iqr2)

# 이상치 눈으로 확인
df_st_cu = pd.merge(strange_df2, transactions, how="inner", on="customer_id")
df_st_cu.sort_values('price', ascending=False).reset_index().head(100)

# 이상치 판단 x


# 파생변수

# 1. t_dat를 datetime으로 변환 후, year, month, weekday 파생변수 생성
# 날짜 처리
df_full["t_dat"] = pd.to_datetime(df_full["t_dat"])
df_full["month"] = df_full["t_dat"].dt.to_period("M").astype(str)
transactions["t_dat"] = pd.to_datetime(transactions["t_dat"])
transactions["year"] = transactions["t_dat"].dt.year
transactions["month"] = transactions["t_dat"].dt.month
transactions["weekday"] = transactions["t_dat"].dt.day_name()

# 처리 이유 : 연·월·요일 단위로 매출과 거래량의 계절성·요일 효과를 분석해 피크 시점과 저조 구간을 파악하기 위함임.

# 2. age를 10단위로 그룹화 해 연령대 파생변수 생성
# 연령대 파생
customers["age_group"] = (customers["age"] // 10) * 10

# 처리 이유 : 개별 나이 수준의 노이즈를 줄이고 10대·20대·30대 등 연령대별 매출/상품 선호 차이를 비교하기 위한 세그먼트 구분임.


# 3. 재구매 주기 섹션 나누기 (3/6/9/12개월/이상) -> 주기별 고객수 세기

# 고객ID과 거래날짜만 보기: repeat_purchase
repeat_purchase = df_full[['customer_id', 't_dat']].sort_values(by='customer_id', ascending=False).reset_index(drop=True)

#1 거래를 두번 이상 한 고객: cnt_repeat
cnt_repeat = repeat_purchase.groupby('customer_id')['t_dat'].count().reset_index()
cnt_repeat = cnt_repeat.where(cnt_repeat['t_dat'] >= 2).dropna().reset_index(drop=True)

# repeat_purchase에서 거래 두번 이상 한 고객의 고객ID와 거래 날짜 보기: repeat_2plus
repeat_2plus = repeat_purchase[repeat_purchase['customer_id'].isin(cnt_repeat['customer_id'])].reset_index(drop=True)

# 고객별 거래 날짜 정렬
repeat_2plus = repeat_2plus.sort_values(by=['customer_id', 't_dat']).reset_index(drop=True)

# customer ID를 기준으로 t_dat 간 차이의 평균을 계산: mean_diff
repeat_2plus['diff'] = repeat_2plus.groupby('customer_id')['t_dat'].diff()
mean_diff = repeat_2plus.groupby('customer_id')['diff'].mean().reset_index()
mean_diff['mean_days'] = mean_diff['diff'].dt.days
mean_diff = mean_diff.sort_values(by=['mean_days'], ascending=False).reset_index(drop=True)

# 재구매 주기 섹션 나누기 (3/6/9/12개월/이상) -> 주기별 고객수 세기

# 3개월 단위 구간 정의 (단위: 일수)
bins = [0, 90, 180, 270, 365]
labels = ['0-3month', '3-6month', '6-9month', '9-12month']

# 구간 나누기 - cut() 함수 사용
mean_diff['repeat_cycle'] = pd.cut(mean_diff['mean_days'], bins=bins, labels=labels)

# 주기별 고객 수 세기
cnt_mean_diff = mean_diff.groupby('repeat_cycle')['customer_id'].count().reset_index()
cnt_mean_diff

# 처리 이유 : 고객의 평균 구매 간격을 구간화해 단기·중기·장기 재구매 고객 비중을 파악하고 주기별 리텐션 전략(리마인드·프로모션) 설계에 활용하기 위함임.


# 4. 재구매율 계산
purchase_count = (df_full.groupby(['product_group_name', 'customer_id']) # 고객의 상품군별 구매 횟수
                         .size()
                         .reset_index(name='count'))

total_customers = purchase_count.groupby('product_group_name')['customer_id'].count() # 총 고객 수

repurchase_customers = purchase_count[purchase_count['count'] > 1].groupby('product_group_name')['customer_id'].count() # 2회 이상(재구매) 구매 고객 수
repurchase_rate = (repurchase_customers / total_customers).fillna(0)
repurchase_rate = (repurchase_rate.sort_values(ascending=False)
                                  .reset_index(name = 'repurchase_rate')
                                  .head(10))
                                  
# 처리 이유 : 상품군별 총 구매 고객 대비 재구매 고객 비율을 계산해, 어떤 카테고리가 충성도와 리텐션에 더 크게 기여하는지 비교·우선순위화하기 위함임.


# 5. 월 × 상품군별 매출 집계
monthly_sales = (df_full.groupby(['month', 'product_group_name'])['price'].sum().reset_index().rename(columns={'price': 'total_sales'}))

# 처리 이유 : 상품군별 월간 매출 추이를 집계해 시즌성(예: 여름 수영복, 겨울 나이트웨어)과 프로모션 타이밍을 데이터 기반으로 판단하기 위함임.

# 6. channel (판매 채널 텍스트 라벨)
channel_select = {1: "Offline", 2: "Online"}
df_full["channel"] = df_full["sales_channel_id"].map(channel_select)

print(df_full[["sales_channel_id", "channel"]].drop_duplicates().head())

# 처리 이유 : 숫자형 채널 코드를 이해하기 쉬운 텍스트 라벨로 변환해 채널별 거래 수·매출, 연령대×채널×상품군 교차 분석을 수행하기 위함임. 


# 1. 고객 세그먼트별 매출 특징

# 1-1. 연령대 별 매출 구하기

# 분석 코드
age_sales = df_full.groupby("age_group")["price"].sum().reset_index()
print(age_sales)

# 시각화 코드 -- seaborn으로 수정 완료
sns.set(style="white")

plt.figure(figsize=(10, 5))
sns.barplot(data=age_sales, x="age_group", y="price", palette="Set2")

plt.xlabel("Age Group")
plt.ylabel("Total price (SEK)")
plt.title("Total price by Age group")
plt.show()

# 1-2. 연령대 별 평균매출 구하기

# 분석 코드
age_sales = df_full.groupby("age_group")["price"].mean().reset_index()

print(age_sales)

# 시각화 코드
sns.set(style="white")

plt.figure(figsize=(10, 5))
sns.barplot(data=age_sales, x="age_group", y="price", palette="Set2")

plt.xlabel("Age Group")
plt.ylabel("Average Spending (SEK)")
plt.title("Average Spending by Age group")
plt.ylim(0.023, 0.034) # 스케일 수정 통한 평균 매출 수치 비교 극대화
plt.show()

# 1-3. 연령대 별 거래 수 구하기

# 분석 코드
# 연령대별 거래 건수 확인
age_tr_cnt = (df_full["age_group"].value_counts().sort_index().reset_index(name="count"))

age_tr_cnt.columns = ["age_group", "count"]

print(age_tr_cnt)

# 시각화 코드
sns.set(style="white")

plt.figure(figsize=(10, 5))
sns.barplot(data=age_tr_cnt, x="age_group", y="count", palette="Set2")

plt.xlabel("Age Group")
plt.ylabel("Number of Transactions")
plt.title("Number of Transactions by Age group")
plt.show()

# 1-4. 회원상태 별 매출 구하기

# 회원 상태 수 구하기
# 1. Club_member_stauts 탈퇴고객 삭제 (이상치 삭제)
customers = customers[customers['club_member_status'] != 'LEFT CLUB']

# 2. df_full에서 고객ID-회원상태 조합만 뽑고 중복 제거
unique_members = customers[["customer_id", "club_member_status"]].drop_duplicates()

# 3. 회원 상태 수 구하기

club_member_status_cnt = (unique_members["club_member_status"].value_counts().sort_index().rename_axis("club_member_status").reset_index(name="count"))

print(club_member_status_cnt)

# 4. 시각화 하기 (seaborn)

sns.set(style="white")

plt.figure(figsize=(8, 7))

graph = sns.barplot(data=club_member_status_cnt, x = "club_member_status", y = "count", palette="Set2")

graph.set_xticklabels(["Active", "Pre-Active"])

plt.title("Number of Club member status")
plt.xlabel("Club memeber stauts")
plt.ylabel("Number of club_member")
plt.show()

# 분석 코드

# 회원 상태별 매출(가격 합계) 구하기
club_member_price = (df_full.groupby("club_member_status")["price"].sum().reset_index().sort_values("price", ascending=False))

print(club_member_price)

# 시각화 코드

sns.set(style="white")

plt.figure(figsize=(8, 7))

graph = sns.barplot(data=club_member_price, x = "club_member_status", y = "price", palette="Set2")

graph.set_xticklabels(["Active", "Pre-Active"])

plt.title("Total price of Club member status")
plt.xlabel("Club memeber stauts")
plt.ylabel("Total price (SEK)")
plt.show()

# 1-5. 신규회원 중 구매로 이어지지 않은 고객 구하기

# 분석 코드
# 신규회원 중 구매로 이어지지 않은 고객 -> 거래를 안한 고객을 보는 것
# customers, transactions 테이블 left 조인: df_cu_tr
df_cu_tr = pd.merge(customers, transactions, how="left", on="customer_id")

# 신규회원수: filtered_precreate
mask_precreate = (df_cu_tr['club_member_status'] == 'PRE-CREATE')  # 조건
filtered_precreate = df_cu_tr[mask_precreate].drop_duplicates(subset="customer_id")
print('신규회원수', filtered_precreate.shape)

# 신규회원 중 구매로 이어지지 않은 고객의 수: filtered_tr_null
mask_tr_null = (df_cu_tr['club_member_status'] == 'PRE-CREATE') & (df_cu_tr['price'].isna())  # 조건
filtered_tr_null = df_cu_tr[mask_tr_null].reset_index(drop=True)
print('Pre-Create not purchase', filtered_tr_null.shape)

# 시각화 -- seaborn으로 수정 필요. 파이차트 말고 쓸 거 있으면 수정 필요
sns.set(style="white")  # seaborn 스타일 적용

# 신규회원 구매 X / O 건수 계산 (기존 shape 값 활용)
no_purchase = filtered_tr_null.shape[0]                 # 구매 안 한 신규회원 row 수
total_new    = filtered_precreate.shape[0]              # 전체 신규회원 row 수
yes_purchase = total_new - no_purchase                  # 구매한 신규회원 row 수

sizes = [no_purchase, yes_purchase]
labels = ['Pre-Create not purchase', 'Pre-Create made a purchase']

colors = sns.color_palette("Set2", n_colors=len(sizes))

plt.figure(figsize=(6, 6))
plt.pie(
    sizes,
    labels=labels,
    colors=colors,         # seaborn 팔레트 색깔 불러오기
    autopct="%.1f%%",      # 비율 표시
    startangle=90,
    wedgeprops={"edgecolor": "white"}
)
plt.title('Purchase Percentage of Pre-Create')
plt.tight_layout()
plt.show()


# 1-6. 고객별 평균적인 재구매 주기 구하기

# 분석 코드

# 고객ID과 거래날짜만 보기: repeat_purchase
repeat_purchase = df_full[['customer_id', 't_dat']].sort_values(by='customer_id', ascending=False).reset_index(drop=True)

#1 거래를 두번 이상 한 고객: cnt_repeat
cnt_repeat = repeat_purchase.groupby('customer_id')['t_dat'].count().reset_index()
cnt_repeat = cnt_repeat.where(cnt_repeat['t_dat'] >= 2).dropna().reset_index(drop=True)

# repeat_purchase에서 거래 두번 이상 한 고객의 고객ID와 거래 날짜 보기: repeat_2plus
repeat_2plus = repeat_purchase[repeat_purchase['customer_id'].isin(cnt_repeat['customer_id'])].reset_index(drop=True)

# 고객별 거래 날짜 정렬
repeat_2plus = repeat_2plus.sort_values(by=['customer_id', 't_dat']).reset_index(drop=True)

# customer ID를 기준으로 t_dat 간 차이의 평균을 계산: mean_diff
repeat_2plus['diff'] = repeat_2plus.groupby('customer_id')['t_dat'].diff()
mean_diff = repeat_2plus.groupby('customer_id')['diff'].mean().reset_index()
mean_diff['mean_days'] = mean_diff['diff'].dt.days
mean_diff = mean_diff.sort_values(by=['mean_days'], ascending=False).reset_index(drop=True)

# 재구매 주기 섹션 나누기 (3/6/9/12개월/이상) -> 주기별 고객수 세기

# 3개월 단위 구간 정의 (단위: 일수)
bins = [0, 90, 180, 270, 365]
labels = ['0-3month', '3-6month', '6-9month', '9-12month']

# 구간 나누기 - cut() 함수 사용
mean_diff['repeat_cycle'] = pd.cut(mean_diff['mean_days'], bins=bins, labels=labels)

# 주기별 고객 수 세기
cnt_mean_diff = mean_diff.groupby('repeat_cycle')['customer_id'].count().reset_index()
cnt_mean_diff

# 시각화 코드

sns.set(style="white")
plt.figure(figsize=(10, 6))

graph = sns.barplot(data=cnt_mean_diff, x="repeat_cycle", y="customer_id", palette="Set2")

plt.title("Number of Customers by Purchase Cycle Group")
plt.xlabel("Purchase Cycle Group")
plt.ylabel("Number of Customers")
plt.xticks(fontsize=9)   
plt.show()

# 2. 상품군 별 트렌드는 무엇인가?

# 2-1. 상품군별 매출 TOP 10 구하기 + TOP 10 에서 각 상품군별 인기색상 구하기

# 상품군별 매출 TOP 10 구하기
# 분석 코드
# TOP 10 분석
top_products = (df_full.groupby("product_group_name")["price"].sum().nlargest(10).reset_index(name="total_sales"))

top_products

# 시각화 코드
top_products = (df_full.groupby("product_group_name")["price"].sum().nlargest(10).reset_index(name="total_sales"))

top_products

plt.figure(figsize=(8, 6))
sns.barplot(data=top_products, x="total_sales", y="product_group_name", orient="h", palette="Set2")
plt.title("Top 10 Product Groups by Sales")
plt.xlabel("Total Sales (SEK)")
plt.ylabel("Product Group")
plt.grid(False)
plt.show()

# TOP 10 리스트 추출
top_products = (df_full.groupby("product_group_name")["price"].sum().nlargest(10))

top_groups = top_products.index

top_groups

# top 10 상품군만 필터링
colors = "perceived_colour_master_name"

df_top = df_full[df_full["product_group_name"].isin(top_groups)]

df_top

# TOP 10에서 각 상품군별 인기색상 구하기
# 분석 코드
top_colors = (df_top.groupby(["product_group_name", colors])["price"].sum().groupby(level=0, group_keys=False).nlargest(5).reset_index())

top_colors.columns = ["product_group_name", "color", "total_sales"]
print(top_colors)

# 시각화 코드
# 색상 이름과 실제 색을 매칭할 팔레트(dict으로 만들어 놓고 사용하기)
color_palette = {
    "Black":  "#000000",
    "White":  "#F5F5F5",
    "Blue":   "#1f77b4",
    "Beige":  "#f5deb3",
    "Grey":   "#808080",
    "Pink":   "#ff69b4",
    "Red":    "#d62728",
    "Brown":  "#8B4513",
    "Orange": "#ff7f0e",
    "Metal":  "#b0c4de",   # 회색으로 대체
}


sns.set(style='white') # seaborn 스타일 선택

for graph in top_groups: # 루프 돌려서 top 10 상품군 연속으로 그래프 생성하기
    graph_colors = top_colors[top_colors["product_group_name"] == graph] # 해당 상품군만 필터
    graph_colors = graph_colors.sort_values("total_sales", ascending=False) # 매출 기준 오름차순 정렬

    plt.figure(figsize=(10, 5))
    sns.barplot(data = graph_colors, x = "color", y = "total_sales", hue="color", dodge = False, palette=color_palette)
    plt.title(f"Top 5 Colors in {graph}")
    plt.xlabel("Color")
    plt.ylabel("Total Sales (SEK)")
    plt.xticks(rotation=360)
    plt.show()


# 2-2. 전체 상품 색상 분포

# 분석 코드 
import seaborn as sns
import matplotlib.pyplot as plt

color_palette_all = {
    "Black":           "#000000",
    "White":           "#F5F5F5",
    "Blue":            "#1f77b4",
    "Pink":            "#ff69b4",
    "Grey":            "#808080",
    "Red":             "#d62728",
    "Beige":           "#f5deb3",
    "Green":           "#2ca02c",
    "Khaki green":     "#708238",
    "Yellow":          "#ffd700",
    "Orange":          "#ff7f0e",
    "Brown":           "#8B4513",
    "Metal":           "#b0c4de",
    "Turquoise":       "#40E0D0",
    "Mole":            "#70543E",
    "Lilac Purple":    "#C8A2C8",
    "Yellowish Green": "#9ACD32",
    "Bluish Green":    "#20B2AA",
    "Unknown":         "#d3d3d3",
    "undefined":       "#d3d3d3",
}

what_colour = (
    articles.groupby('perceived_colour_master_name')['article_id']
    .count()
    .sort_values(ascending=False)
    .reset_index(name='cnt_colour')
)
print(what_colour)

# 시각화 코드
sns.set(style="white")

plt.figure(figsize=(10, 5))
sns.barplot(
    data=what_colour,
    x="perceived_colour_master_name",
    y="cnt_colour",
    palette=color_palette_all
)

plt.title("Distribution of Product Colors")
plt.xlabel("Color")
plt.ylabel("Number of Articles")
plt.xticks(rotation=45, ha='right')
plt.tight_layout()
plt.show()


# 2-3. 상품군별 재구매율 파악하기

# 분석 코드
purchase_count = (df_full.groupby(['product_group_name', 'customer_id']) # 고객의 상품군별 구매 횟수
                         .size()
                         .reset_index(name='count'))

total_customers = purchase_count.groupby('product_group_name')['customer_id'].count() # 총 고객 수

repurchase_customers = purchase_count[purchase_count['count'] > 1].groupby('product_group_name')['customer_id'].count() # 2회 이상(재구매) 구매 고객 수

# 재구매율 계산 후 상위 10개
repurchase_rate = (repurchase_customers / total_customers).fillna(0)
repurchase_rate = (repurchase_rate.sort_values(ascending=False)
                                  .reset_index(name = 'repurchase_rate')
                                  .head(10))


# 시각화 코드

sns.set(style='white')

plt.figure(figsize=(10, 9))
sns.barplot(data=repurchase_rate, x="repurchase_rate", y="product_group_name", palette="Set2", orient="h")

plt.xlabel("Repurchase Rate")
plt.ylabel("Product Group")
plt.title("Repurchase Rate by Product Group")
plt.tight_layout()
plt.show()



# 2-4. 상품군별 월 매출 동향

# 분석 코드
# 월 × 상품군별 매출 집계
monthly_sales = (df_full.groupby(['month', 'product_group_name'])['price'].sum().reset_index().rename(columns={'price': 'total_sales'}))

# 피벗테이블로 변환
monthly_pivot = monthly_sales.pivot_table(index='month',columns='product_group_name',values='total_sales',fill_value=0)

monthly_pivot

# 시각화 코드 
sns.set(style="white")

plt.figure(figsize=(12, 6))
sns.lineplot(data=monthly_sales, x="month", y="total_sales", hue="product_group_name", palette="Set2") # 상품군별 라인 분리

plt.xlabel("Month")
plt.ylabel("Total price (SEK)")
plt.title("Monthly sales by product_group_name")
plt.legend(title="Product group", bbox_to_anchor=(1.02, 1), loc="upper left")
plt.tight_layout()
plt.show()

# 번외 그래프 경향성 보이는 애들만 따로 시각화

# 1) 상품군별 월매출 변동(표준편차) 계산
std_by_group = (monthly_sales.groupby("product_group_name")["total_sales"].std())

# 2) 일정 이상 변동이 있는 상품군만 선택
threshold = 30 # 표준편차가 30보다 더 큰 상품군만 선택
keep_groups = std_by_group[std_by_group > threshold].index

print("남길 상품군 목록:")
print(list(keep_groups))

# 3) 필터링된 데이터로만 시각화
filtered_sales = monthly_sales[monthly_sales["product_group_name"].isin(keep_groups)]

sns.set(style="white")

plt.figure(figsize=(12, 6))
sns.lineplot(data=filtered_sales, x="month", y="total_sales", hue="product_group_name", linewidth=3)

plt.xlabel("Month")
plt.ylabel("Total price (SEK)")
plt.title("Monthly sales by product group (variable groups only)")
plt.legend(title="Product group", bbox_to_anchor=(1.02, 1), loc="upper left")
plt.tight_layout()
plt.show()


# 3. 연령대별 채널(온, 오프라인) 사용 현황 + 연령대별 매출 상위 10개 상품군 구하기


# 3-1. 연령대별 채널 사용 현황

# 분석 코드
age_channel_cnt = (df_full.groupby(["age_group", "sales_channel_id"]).size().reset_index(name="count").sort_values(["age_group", "sales_channel_id"]))


# 채널명 컬럼 추가(1 : offline, 2 : online)
channel_select = {1: "Offline", 2: "Online"}
age_channel_cnt["channel"] = age_channel_cnt["sales_channel_id"].map(channel_select)

print(age_channel_cnt)

# 시각화 코드

sns.set(style="white")

plt.figure(figsize=(8, 7))

graph2 = sns.barplot(data=age_channel_cnt, x = "age_group", y = "count", hue="channel", palette="Set2")

plt.title("Number of Transactions by Age Group and Channel")
plt.xlabel("Age Group")
plt.ylabel("Number of Transactions")
graph2.legend(title="Channel")

plt.show()

# 3-2. 연령대별 매출 상위 10개 상품군 구하기

# 분석 코드
# 연령대, 채널, 상품군별 매출 집계
age_channel_pg_sales = (df_full.groupby(["age_group", "sales_channel_id", "product_group_name"])["price"].sum().reset_index())

channel_select = {1: "Offline", 2: "Online"}
age_channel_pg_sales["channel"] = age_channel_pg_sales["sales_channel_id"].map(channel_select)

age_channel_pg_sales

# 각 연령대 x 온, 오프라인별 top 10 상품군 추출 (리스트 형성)
top_list = []

for (age, ch), sub in age_channel_pg_sales.groupby(["age_group", "sales_channel_id"]):
    top10 = (sub.sort_values("price", ascending=False).head(10).copy())

    top10["segment"] = f"{age}대 - {ch}"
    top_list.append(top10)

top10_pg_by_segment = pd.concat(top_list, ignore_index=True)

channel_select = {1: "Offline", 2: "Online"}
top10_pg_by_segment["channel"] = top10_pg_by_segment["sales_channel_id"].map(channel_select)

top10_pg_by_segment

# 시각화 코드
sns.set(style="white")

for age, sub in top10_pg_by_segment.groupby("age_group"):
    order = (sub.groupby("product_group_name")["price"].sum().sort_values(ascending=False).index)

    plt.figure(figsize=(20, 5))
    sns.barplot(data = sub, x = "product_group_name", y = "price", hue="channel", dodge = True, palette="Set2")
    plt.title(f"Top 10 Product Groups by Sales ({age}'s)")
    plt.xlabel("Product Group")

    plt.ylabel("Total Sales (SEK)")
    plt.legend(title="Channel")
    plt.show()
